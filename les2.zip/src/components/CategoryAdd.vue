<template>
    <form @submit.prevent="addCategory">
        <div>
            <input type="text" v-model="name"/>
            <span v-show="error == '' ? false : true">{{ error }}</span>
        </div>
        <button>Create</button>
    </form>
</template>
<script>
    export default{
        props: ['error'],
        data(){
            return{
                name: '',
            }
        },
        methods:{
            addCategory()
            {
                const category = {
                    name: this.name
                }
                this.$emit('add_category', category)
                this.name = ''
            }
        }
    }
</script>
<style scoped>
    div{
        display: grid;
    }
    span{
        color: crimson;
    }
    form{
        display: grid;
        grid-template-columns: 3fr 1fr;
    }
</style>