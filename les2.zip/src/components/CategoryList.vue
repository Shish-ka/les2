<template>

    <ul>
        <CategoryItem 
        v-for="category in categories" 
        :category="category"
        @remove_category="removeCategory"
        />
    </ul>
</template>

<script>
    import CategoryItem from './CategoryItem.vue';
    export default{
        components:{
            CategoryItem, 
        },
        props:['categories'],
        methods:{
            removeCategory(id)
            {
                this.$emit('remove_category', id);
            }
        }
    }
</script>