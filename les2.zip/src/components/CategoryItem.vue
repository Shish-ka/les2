<template>
    <li>
        <b>{{ category.id }}</b>
        <span>{{ category.name }}</span>
        <button @click="$emit('remove_category',category.id)">&times;</button>
    </li>
</template>

<script>
    export default{
        props:['category']
    }
</script>