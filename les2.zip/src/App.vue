<script >
  import CategoryList from './components/CategoryList.vue';
  import CategoryAdd from './components/CategoryAdd.vue';
  export default{
    components:{
      CategoryList,CategoryAdd
    },
    data(){
      return{
        categories: [],
        error: '',
      }
    },
    methods:{
      async loadCategories()
        {
          const response = await fetch('http://srvydy.ru/api/categories');
          this.categories = await response.json()
        },
      
      async addCategory(category)
      {
        const response = await fetch('http://srvydy.ru/api/categories', {
          method: 'POST',
          headers: { 'Accept': 'application/json', 'Content-Type': 'application/json'},
          body: JSON.stringify(category)
        });
        const res = await response.json()
        if(res.category){
          this.error = '',
          this.loadCategories()
        }else{
          this.error = res.errors.name[0]
        }
        this.loadCategories()
      },
      async removeCategory(id)
      {
        // this.categories = this.categories.filter(category => category.id != id)
        const response = await fetch('http://srvydy.ru/api/categories/'+id, {
          method: 'DELETE',
          headers: { 'Accept': 'application/json', 'Content-Type': 'application/json'},
        });
        console.log()
        this.loadCategories()
      }
    },
    mounted(){
      this.loadCategories()
    }
  }
</script>

<template>
    <h1>Category List</h1>
    <hr>
      <CategoryAdd 
        @add_category="addCategory"
        :error="error"
        />
    <hr>
    <CategoryList 
      :categories="categories"
      @remove_category="removeCategory"
    />
</template>

<style scoped>

</style>
